# MASTER PROMPT FOR GOOGLE AI STUDIO

You are finishing the Zondoe School Management System V4. Do NOT throw away the existing code. Inspect the whole imported project first, preserve the working UI and architecture, then upgrade it into a production-ready full-stack school-management platform.

GOAL
Build one complete multi-school platform where a school can register itself, configure its school information, create users, manage students/staff/classes/subjects, attendance, fees, payments, exams/results, timetable, assignments, announcements, reports, documents, expenses and parent/student portals. All data must belong to a school_id and school users must be able to edit the data they are authorized to edit.

VIDEO SCOPE TO IMPLEMENT
The supplied reference video describes the core idea of a centralized school-management platform. Include ALL of these functional areas:
1. School registration/onboarding
2. School dashboard
3. Digital student records/identity
4. Student registration and searchable database
5. Class/section management
6. Teachers/staff
7. Fees and fee assignments
8. Student balances
9. Payment recording and history
10. Payment notifications/confirmation
11. Attendance and attendance history
12. Reminders/announcements
13. PDF/Excel/CSV reporting/export
14. Search/filter/table actions
15. Exams/results/report cards
16. Timetable
17. Assignments
18. Parent access
19. Student access
20. Digital student ID/QR
21. Expenses
22. User roles and permissions
23. Audit/history
24. AI assistant

LIBERIA PAYMENT REQUIREMENTS
Provide configurable methods:
- MTN Mobile Money
- Orange Money
- Cash
- Bank Transfer / Deposit
- Bank Card / POS
- Other/custom
Each method must support enabled/disabled, merchant/wallet/account reference, instructions, currency, transaction/reference ID and reconciliation fields.
Payment records must support pending, confirmed, failed, refunded; amount, payer name, payer phone, fees/charges, date/time, method, transaction reference, receiver/confirming user, notes and receipt.
NEVER store mobile-money PINs.
Do not claim live MTN or Orange API integration unless real provider credentials/API documentation are configured. Build provider adapters/interfaces and webhook-ready endpoints so approved integrations can be added later.

ROLES
- Super Admin
- School Owner / Administrator
- Finance Officer
- Registrar
- Teacher
- Parent/Guardian
- Student
Enforce school isolation and role permissions in Supabase RLS, not only in the UI.

DATABASE
Use the included Supabase schema as the baseline. Finish all relationships, indexes, constraints, RLS policies, triggers and audit logging. Add created_by/updated_by/updated_at where useful.

AUTH
Implement Supabase Auth with:
- sign up/login
- school onboarding
- invite staff
- parent/student account linking
- password reset
- session persistence
- role-based routing
- school membership
A school administrator must be able to edit school name, logo, address, phone, email, currency, academic year, terms, classes, subjects, fee types, payment methods, notification settings and staff.

STUDENT MANAGEMENT
Implement:
- registration form
- student number generation
- photo/profile
- guardian details
- class/section
- address/contact
- medical/emergency fields only if appropriate and securely protected
- searchable table
- filters
- profile page
- attendance history
- fee balance
- payment history
- results
- assignments
- timetable
- digital ID card
- QR code that identifies the student without exposing sensitive information

FEES/PAYMENTS
Implement:
- fee types
- fee schedules
- assign fees to classes/students
- discounts
- balances
- payment entry
- receipts
- payment status workflow
- daily/monthly/yearly finance reports
- reconciliation
- export
- printable receipt
- notification after confirmed payment
Do not reduce a student's balance until payment is confirmed.
Use database transactions where necessary.

ATTENDANCE
Teachers should take class attendance. Admins can review/edit according to permissions. Include daily, weekly, monthly and student history views and attendance reports.

EXAMS
Create exams and subjects, enter marks, calculate percentage and grade, remarks, publish/unpublish results, produce printable/downloadable report cards.

PARENT/STUDENT PORTALS
Parents can see linked children only. Students can see their own records only. Include fees, receipts, balances, attendance, results, assignments, timetable, announcements and digital ID.

REPORTING
Implement CSV and Excel export plus printable PDF/receipt/report-card generation. Add filters by date, class, student, payment method, status and term.

AI ASSISTANT
Keep the included /api/ai endpoint. Use Gemini server-side. The AI must have role-aware access and only receive the minimum school data needed. It can:
- answer school dashboard questions
- summarize fee collections
- identify outstanding balances
- explain attendance trends
- help create announcements/reminders
- explain how to use the system
- draft report comments
- summarize exam performance
It must not invent transactions or claim to have changed data unless an actual authorized tool call performed the change.
Use GOOGLE_GENAI_API_KEY only on the server side.

UI
Keep the professional dark navy + white dashboard style, but make it original Zondoe branding. Mobile-first, accessible, responsive. On small screens use a bottom navigation or collapsible sidebar. Every button must either work or clearly indicate what is pending.

SECURITY
- Never expose service-role keys in browser code.
- Never store mobile-money PINs.
- Use RLS for school isolation.
- Validate all financial writes server-side/database-side.
- Verify payment webhooks before changing payment status.
- Log sensitive administrative changes in audit_logs.
- Add rate limiting to public endpoints.
- Protect documents with Storage policies.
- Do not put secrets in VITE_ variables.

QUALITY PROCESS
After each major module:
1. run/build the app
2. fix TypeScript errors
3. fix runtime errors
4. test create/read/update/delete
5. test role permissions
6. test school isolation
7. test mobile layout
8. verify exports
9. verify payment status/balance logic
10. keep the project compiling

FINAL ACCEPTANCE TEST
A new school administrator must be able to:
register a school -> configure payment methods -> create classes -> create staff -> register students -> assign fees -> record an MTN/Orange/cash/bank/card payment -> issue receipt -> confirm notification -> take attendance -> create exams/results -> publish report card -> create timetable/assignments/announcements -> view reports -> use AI assistant.

Do not stop at mock screens. Implement real CRUD with Supabase wherever credentials are configured, while keeping a demo fallback for preview.
