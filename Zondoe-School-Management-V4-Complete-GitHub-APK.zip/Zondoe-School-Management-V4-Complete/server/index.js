import express from "express";
const app=express(); app.use(express.json());
const port=process.env.PORT||3001;
app.post("/api/ai",async(req,res)=>{
  const {question,school,summary}=req.body||{};
  const key=process.env.GOOGLE_GENAI_API_KEY;
  if(!key) return res.json({answer:"AI is ready but no Gemini server key is configured. In Google AI Studio, add GOOGLE_GENAI_API_KEY as a server-side secret, then restart the app."});
  try{
    const model=process.env.AI_MODEL||"gemini-2.5-flash";
    const prompt=`You are the Zondoe School Management AI Assistant. Be concise, practical and safe. School: ${JSON.stringify(school)}. Current summary: ${JSON.stringify(summary)}. User question: ${question}. Do not invent financial transactions or student facts. If asked to change data, explain what should be changed rather than pretending it was changed.`;
    const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:prompt}]}]})});
    const j=await r.json(); const answer=j?.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("")||"No AI response.";
    res.json({answer});
  }catch(e){res.status(500).json({answer:"The AI service could not be reached. Check the server-side Gemini key and model configuration."});}
});
app.listen(port,()=>console.log(`Zondoe server listening on ${port}`));
