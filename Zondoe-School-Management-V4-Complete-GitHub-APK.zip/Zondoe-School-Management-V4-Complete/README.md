# Zondoe School Management System — V4 Complete Foundation

This package is designed to be uploaded/imported into Google AI Studio Build mode and then completed/verified by the AI Studio agent.

## Included
- Multi-school architecture and school registration/settings
- Student registration/searchable records
- Teachers & staff
- Classes, sections and subjects
- Attendance
- Fees, student balances and payment ledger
- Liberia payment-method configuration: MTN Mobile Money, Orange Money, Cash, Bank Transfer/Deposit, Bank Card/POS and Other
- Payment status, transaction references, payer information and receipt records
- Exams, results and report-card data model
- Timetable and assignments
- Announcements/notifications
- Expenses
- Documents
- Users/roles and audit logs
- CSV export foundation
- Zondoe AI Assistant with secure server endpoint
- Supabase PostgreSQL schema + RLS foundation
- Responsive/mobile-first UI

## Important payment note
Liberia's current national instant-payment infrastructure includes interoperability between Lonestar MTN and Orange Money. This app stores/configures those methods but does NOT pretend to have live provider API credentials. Live collection/refunds/webhooks require approved merchant/provider credentials and current provider API documentation. Never store mobile-money PINs.

## AI
Set `GOOGLE_GENAI_API_KEY` as a server-side secret in Google AI Studio. Never put it in VITE_ client variables.

## Run locally
npm install
npm run dev

For AI endpoint:
GOOGLE_GENAI_API_KEY=... npm run server

## Production checklist
- Complete Supabase authentication and role-specific RLS policies.
- Add secure storage policies for documents.
- Add PDF/Excel generation.
- Add payment-provider APIs only after credentials and documentation are supplied.
- Add webhook signature verification and reconciliation.
- Add backups, audit review, rate limiting and error monitoring.
- Test every CRUD flow on desktop and Android/mobile.
