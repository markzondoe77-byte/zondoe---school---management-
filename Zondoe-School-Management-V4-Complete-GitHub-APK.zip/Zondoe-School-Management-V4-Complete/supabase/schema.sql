-- Zondoe School Management System V4
-- Run in Supabase SQL Editor. This schema is designed for multi-school isolation.
create extension if not exists pgcrypto;

create table if not exists schools(
 id uuid primary key default gen_random_uuid(), name text not null, address text, phone text, email text,
 logo_url text, currency text not null default 'USD' check(currency in ('USD','LRD')),
 academic_year text, current_term text, receipt_prefix text default 'REC', created_at timestamptz default now()
);
create table if not exists profiles(
 id uuid primary key references auth.users(id) on delete cascade, school_id uuid references schools(id) on delete cascade,
 full_name text, phone text, role text not null default 'teacher',
 created_at timestamptz default now()
);
create table if not exists classes(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 name text not null, section text, teacher_id uuid references profiles(id), capacity int default 40, created_at timestamptz default now()
);
create table if not exists subjects(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 name text not null, code text, created_at timestamptz default now()
);
create table if not exists students(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 student_no text not null, first_name text not null, last_name text not null, gender text, dob date,
 class_id uuid references classes(id), section text, guardian_name text, guardian_phone text, address text,
 status text default 'active', qr_token text default encode(gen_random_bytes(12),'hex'), created_at timestamptz default now(),
 unique(school_id,student_no)
);
create table if not exists fee_types(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 name text not null, amount numeric(14,2) not null default 0, frequency text default 'Term', class_id uuid references classes(id),
 due_date date, created_at timestamptz default now()
);
create table if not exists student_fees(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 student_id uuid not null references students(id) on delete cascade, fee_type_id uuid references fee_types(id),
 amount numeric(14,2) not null default 0, discount numeric(14,2) default 0, due_date date, status text default 'unpaid'
);
create table if not exists payment_methods(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 name text not null, enabled boolean default true, account_reference text, instructions text, currency text default 'USD',
 created_at timestamptz default now()
);
create table if not exists payments(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 student_id uuid references students(id), amount numeric(14,2) not null, method_id uuid references payment_methods(id),
 method_name text, status text not null default 'pending' check(status in ('pending','confirmed','failed','refunded')),
 transaction_reference text, payer_name text, payer_phone text, payment_date timestamptz default now(),
 fees_charged numeric(14,2) default 0, notes text, confirmed_by uuid references profiles(id), created_at timestamptz default now()
);
create table if not exists payment_receipts(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 payment_id uuid not null references payments(id) on delete cascade, receipt_number text not null,
 issued_at timestamptz default now(), pdf_path text
);
create table if not exists attendance(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 student_id uuid not null references students(id) on delete cascade, attendance_date date not null,
 status text not null check(status in ('present','absent','late','excused')), note text, recorded_by uuid references profiles(id),
 unique(student_id,attendance_date)
);
create table if not exists exams(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 name text not null, term text, exam_date date, created_at timestamptz default now()
);
create table if not exists results(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 exam_id uuid references exams(id) on delete cascade, student_id uuid references students(id) on delete cascade,
 subject_id uuid references subjects(id), score numeric(8,2), max_score numeric(8,2) default 100, grade text, remark text
);
create table if not exists timetable(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 class_id uuid references classes(id), subject_id uuid references subjects(id), teacher_id uuid references profiles(id),
 day_of_week text, start_time time, end_time time, room text
);
create table if not exists assignments(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 class_id uuid references classes(id), subject_id uuid references subjects(id), teacher_id uuid references profiles(id),
 title text, description text, due_date date, attachment_path text, created_at timestamptz default now()
);
create table if not exists announcements(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 title text not null, message text not null, audience text default 'All', published_at timestamptz default now()
);
create table if not exists expenses(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 category text, description text, amount numeric(14,2) not null, payee text, reference text, expense_date date default current_date,
 status text default 'approved', recorded_by uuid references profiles(id), created_at timestamptz default now()
);
create table if not exists documents(
 id uuid primary key default gen_random_uuid(), school_id uuid not null references schools(id) on delete cascade,
 student_id uuid references students(id), staff_id uuid references profiles(id), title text, storage_path text, document_type text, created_at timestamptz default now()
);
create table if not exists audit_logs(
 id uuid primary key default gen_random_uuid(), school_id uuid references schools(id) on delete cascade,
 actor_id uuid references profiles(id), action text, entity_type text, entity_id uuid, details jsonb, created_at timestamptz default now()
);
create table if not exists notifications(
 id uuid primary key default gen_random_uuid(), school_id uuid references schools(id) on delete cascade,
 recipient_id uuid references profiles(id), title text, message text, channel text default 'in_app', status text default 'queued', created_at timestamptz default now()
);

-- Seed Liberia payment methods for each school after a school is created.
-- Live provider APIs are NOT implied by these records.
-- Never store MTN/Orange PINs.
insert into payment_methods(school_id,name,enabled,instructions,currency)
select s.id,'MTN Mobile Money',true,'Enter the school-approved MTN merchant/wallet reference. Do not request or store PIN.',s.currency from schools s
where not exists(select 1 from payment_methods p where p.school_id=s.id and p.name='MTN Mobile Money');
insert into payment_methods(school_id,name,enabled,instructions,currency)
select s.id,'Orange Money',true,'Enter the school-approved Orange merchant/wallet reference. Do not request or store PIN.',s.currency from schools s
where not exists(select 1 from payment_methods p where p.school_id=s.id and p.name='Orange Money');
insert into payment_methods(school_id,name,enabled,currency) select s.id,'Cash',true,s.currency from schools s where not exists(select 1 from payment_methods p where p.school_id=s.id and p.name='Cash');
insert into payment_methods(school_id,name,enabled,currency) select s.id,'Bank Transfer / Deposit',true,s.currency from schools s where not exists(select 1 from payment_methods p where p.school_id=s.id and p.name='Bank Transfer / Deposit');
insert into payment_methods(school_id,name,enabled,currency) select s.id,'Bank Card / POS',true,s.currency from schools s where not exists(select 1 from payment_methods p where p.school_id=s.id and p.name='Bank Card / POS');
insert into payment_methods(school_id,name,enabled,currency) select s.id,'Other',true,s.currency from schools s where not exists(select 1 from payment_methods p where p.school_id=s.id and p.name='Other');

-- Enable RLS.
alter table schools enable row level security;
alter table profiles enable row level security;
alter table classes enable row level security;
alter table subjects enable row level security;
alter table students enable row level security;
alter table fee_types enable row level security;
alter table student_fees enable row level security;
alter table payment_methods enable row level security;
alter table payments enable row level security;
alter table payment_receipts enable row level security;
alter table attendance enable row level security;
alter table exams enable row level security;
alter table results enable row level security;
alter table timetable enable row level security;
alter table assignments enable row level security;
alter table announcements enable row level security;
alter table expenses enable row level security;
alter table documents enable row level security;
alter table audit_logs enable row level security;
alter table notifications enable row level security;

-- Helper: authenticated user's school.
create or replace function public.my_school_id() returns uuid language sql stable security definer set search_path=public as $$
 select school_id from public.profiles where id=auth.uid()
$$;

-- Base policies. School admins and users can access only their own school's rows.
-- AI Studio should tighten write policies by role before production.
do $$
declare t text;
begin
 for t in select unnest(array['schools','profiles','classes','subjects','students','fee_types','student_fees','payment_methods','payments','payment_receipts','attendance','exams','results','timetable','assignments','announcements','expenses','documents','audit_logs','notifications'])
 loop
   execute format('drop policy if exists "school isolation" on public.%I',t);
   execute format('create policy "school isolation" on public.%I for all to authenticated using (school_id = public.my_school_id() or id = public.my_school_id()) with check (school_id = public.my_school_id() or id = public.my_school_id())',t);
 end loop;
end$$;
