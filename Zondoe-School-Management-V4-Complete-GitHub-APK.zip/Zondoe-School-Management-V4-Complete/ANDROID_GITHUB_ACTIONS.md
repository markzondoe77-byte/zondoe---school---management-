# Build the Zondoe School Management APK with GitHub Actions

## 1. Upload this project to GitHub
Create a GitHub repository and upload all files in this project.

## 2. Run the build
Open the repository's **Actions** tab, select **Build Zondoe School Management APK**, then click **Run workflow**.

You can also trigger it automatically by pushing to `main` or `master`.

## 3. Download the APK
When the workflow finishes successfully:
Actions -> Build Zondoe School Management APK -> latest successful run -> Artifacts -> `zondoe-school-management-debug-apk`.

The downloaded ZIP contains `app-debug.apk`.

## Important
This workflow packages the current Vite/React application as an Android Capacitor app. The current project also contains a Node/Express AI server. That server is NOT embedded inside the APK; the APK can only use the AI endpoint if it is deployed to an accessible HTTPS server and the app is configured to call that server.

The APK produced here is a debug APK for testing. A Play Store/release APK or AAB should be created later with a signing key.
