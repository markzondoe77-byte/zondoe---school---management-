export type Role = "super_admin"|"school_admin"|"finance"|"registrar"|"teacher"|"parent"|"student";
export type PaymentStatus = "pending"|"confirmed"|"failed"|"refunded";
export type ModuleKey = "dashboard"|"onboarding"|"students"|"staff"|"classes"|"attendance"|"fees"|"payments"|"exams"|"timetable"|"assignments"|"announcements"|"reports"|"expenses"|"users"|"documents"|"settings"|"ai";

export interface School { id:string; name:string; address:string; phone:string; email:string; logo_url:string; currency:"USD"|"LRD"; academic_year:string; current_term:string; receipt_prefix:string; }
export interface Student { id:string; school_id:string; student_no:string; first_name:string; last_name:string; gender:string; dob:string; class_name:string; section:string; guardian_name:string; guardian_phone:string; address:string; status:"active"|"inactive"; balance:number; }
export interface Staff { id:string; school_id:string; name:string; role:string; phone:string; email:string; subject:string; status:"active"|"inactive"; }
export interface ClassRoom { id:string; school_id:string; name:string; section:string; teacher:string; capacity:number; }
export interface Attendance { id:string; student_id:string; date:string; status:"present"|"absent"|"late"|"excused"; note:string; }
export interface Fee { id:string; school_id:string; name:string; amount:number; frequency:string; class_name:string; due_date:string; }
export interface Payment { id:string; school_id:string; student_id:string; amount:number; method:string; status:PaymentStatus; reference:string; payer_name:string; payer_phone:string; date:string; notes:string; }
export interface ExamResult { id:string; school_id:string; student_id:string; subject:string; exam:string; score:number; max_score:number; grade:string; term:string; }
export interface Announcement { id:string; school_id:string; title:string; message:string; audience:string; date:string; }
