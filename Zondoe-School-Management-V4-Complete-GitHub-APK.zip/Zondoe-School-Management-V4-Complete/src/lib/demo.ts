import { School, Student, Staff, ClassRoom, Payment, Fee, ExamResult, Announcement } from "../types";
export const demoSchool:School={id:"school-demo",name:"Zondoe High School",address:"Monrovia, Liberia",phone:"+231 770 000 000",email:"admin@zondoe.school",logo_url:"",currency:"USD",academic_year:"2026/2027",current_term:"First Term",receipt_prefix:"ZHS"};
export const demoStudents:Student[]=[
{id:"s1",school_id:"school-demo",student_no:"ZHS-001",first_name:"Grace",last_name:"Harris",gender:"Female",dob:"2012-04-10",class_name:"Grade 7",section:"A",guardian_name:"Mary Harris",guardian_phone:"+231 770 111 111",address:"Sinkor, Monrovia",status:"active",balance:120},
{id:"s2",school_id:"school-demo",student_no:"ZHS-002",first_name:"Mark",last_name:"Zondoe",gender:"Male",dob:"2011-09-21",class_name:"Grade 8",section:"A",guardian_name:"John Zondoe",guardian_phone:"+231 770 222 222",address:"Paynesville",status:"active",balance:0},
{id:"s3",school_id:"school-demo",student_no:"ZHS-003",first_name:"Rachel",last_name:"Johnson",gender:"Female",dob:"2010-02-18",class_name:"Grade 9",section:"B",guardian_name:"Sarah Johnson",guardian_phone:"+231 770 333 333",address:"Congo Town",status:"active",balance:75}
];
export const demoStaff:Staff[]=[
{id:"t1",school_id:"school-demo",name:"David Cooper",role:"Teacher",phone:"+231 770 444 444",email:"david@zondoe.school",subject:"Mathematics",status:"active"},
{id:"t2",school_id:"school-demo",name:"Mary Johnson",role:"Registrar",phone:"+231 770 555 555",email:"mary@zondoe.school",subject:"",status:"active"}
];
export const demoClasses:ClassRoom[]=[
{id:"c1",school_id:"school-demo",name:"Grade 7",section:"A",teacher:"David Cooper",capacity:35},
{id:"c2",school_id:"school-demo",name:"Grade 8",section:"A",teacher:"David Cooper",capacity:35},
{id:"c3",school_id:"school-demo",name:"Grade 9",section:"B",teacher:"David Cooper",capacity:35}
];
export const demoFees:Fee[]=[
{id:"f1",school_id:"school-demo",name:"Tuition",amount:500,frequency:"Term",class_name:"All",due_date:"2026-10-15"},
{id:"f2",school_id:"school-demo",name:"Registration",amount:50,frequency:"Annual",class_name:"All",due_date:"2026-09-30"}
];
export const demoPayments:Payment[]=[
{id:"p1",school_id:"school-demo",student_id:"s2",amount:500,method:"MTN Mobile Money",status:"confirmed",reference:"MTN-2026-0001",payer_name:"John Zondoe",payer_phone:"+231770222222",date:"2026-09-19",notes:"Tuition"},
{id:"p2",school_id:"school-demo",student_id:"s1",amount:300,method:"Orange Money",status:"confirmed",reference:"OM-2026-0002",payer_name:"Mary Harris",payer_phone:"+231770111111",date:"2026-09-18",notes:"Part payment"}
];
export const demoResults:ExamResult[]=[
{id:"r1",school_id:"school-demo",student_id:"s2",subject:"Mathematics",exam:"Mid Term",score:82,max_score:100,grade:"A",term:"First Term"},
{id:"r2",school_id:"school-demo",student_id:"s2",subject:"English",exam:"Mid Term",score:74,max_score:100,grade:"B",term:"First Term"}
];
export const demoAnnouncements:Announcement[]=[
{id:"a1",school_id:"school-demo",title:"Parent Meeting",message:"Parents meeting is scheduled for Friday at 3:00 PM.",audience:"Parents",date:"2026-09-20"},
{id:"a2",school_id:"school-demo",title:"Fee Reminder",message:"Please check outstanding balances before the due date.",audience:"All",date:"2026-09-20"}
];
