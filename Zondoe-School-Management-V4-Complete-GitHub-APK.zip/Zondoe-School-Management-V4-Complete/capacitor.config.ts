import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.zondoe.schoolmanagement',
  appName: 'Zondoe School Management',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
